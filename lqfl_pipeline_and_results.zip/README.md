# LQ-FL reproducible pipeline (numpy statevector, no PennyLane/torch needed)

Files
- data_prep.py  : builds manifests + 134-d HOG/intensity features (HOG 8 bins, 16x16 cells, 64x64 grayscale). Near-duplicate (pHash<=2, cross-group) and md5 removal.
- qsim.py       : exact batched 6-qubit simulator, parameter-shift gradients. `python qsim.py` verifies that the 1-layer circuit has zero RZ-gradient and z_i = product of cosines.
- lqfl.py       : federated continual learning (FedAvg, replay, Q-EWC explicit/proximal, classical controls, joint upper bound), metrics.
- sweep.py, sweep2.py : lambda sweeps on a VALIDATION split carved from the training data (test split untouched).
- run_final.py  : 7-seed runs on the held-out test split (resumable). analyze.py: tables + paired tests. figs.py: figures.
- results_final.jsonl, sweep_val.jsonl, sweep2_val.jsonl, table_all.csv : raw outputs. manifest_*.csv : exact image lists, groups, sources.

Data layout expected under /home/claude/data (edit D in data_prep.py): kermany_normal, kermany_pneu, covid_ieee (+metadata.csv), iqoth, ctrl (+meta/*.metadata.xlsx).

Known limitations: Lung Cancer groups are contiguous 14-slice blocks (no patient ID in IQ-OTH/NCCD); control dataset split is image-level;
scaler/PCA fitted on all training classes ('global'); Fisher reference buffer holds old-class training data (as in the original design); noiseless simulation.

Publishing (GitHub + Zenodo): 1) create a public GitHub repository and push these files (add a LICENSE, e.g. MIT, and do NOT upload the image files themselves, only manifest_*.csv);
2) on zenodo.org log in with GitHub, switch the repository on under Account > GitHub; 3) create a GitHub Release (e.g. v1.0.0): Zenodo archives it automatically and mints a DOI;
4) put the repository URL and the DOI in the Code and Data Availability section of the manuscript.
