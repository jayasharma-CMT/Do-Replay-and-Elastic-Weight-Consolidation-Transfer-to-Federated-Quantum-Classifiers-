import numpy as np, lqfl
from lqfl import *
d = np.load('feat_main.npz', allow_pickle=True)
lab = ['Normal','Pneumonia','COVID-19','Lung Cancer']; y = np.array([lab.index(v) for v in d['y']]); tasks=[[0,1],[2],[3]]
# validation mode (use_val) so test split is untouched
for mode in ['explicit','prox']:
    for cond in ['qewc','replay_qewc','c_replay_ewc']:
        r = run(cond, d['X'], y, d['g'], tasks, 1, cfg_over=dict(use_val=True, penalty_mode=mode))
        print(f"{mode:8s} {cond:13s} val_acc={r['acc']:.3f} bal={r['bal_acc']:.3f} bwt={r['bwt']:.3f} Fmax={getattr(lqfl.fisher,'last',None)}")
