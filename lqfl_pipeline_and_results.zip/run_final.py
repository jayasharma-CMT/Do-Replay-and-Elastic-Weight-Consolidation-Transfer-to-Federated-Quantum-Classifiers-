"""Final 7-seed runs on the held-out TEST split. Resumable: python3 run_final.py <budget_seconds>"""
import numpy as np, json, sys, time, os
from lqfl import *
BUDGET = float(sys.argv[1]); T0 = time.time(); fn = 'results_final.jsonl'
DS = {'main': (['Normal', 'Pneumonia', 'COVID-19', 'Lung Cancer'], 'feat_main.npz'),
      'ctrl': (['Normal', 'Viral Pneumonia', 'COVID', 'Lung_Opacity'], 'feat_ctrl.npz')}
TASKS = [[0, 1], [2], [3]]
SPEC = dict(penalty_mode='explicit', lam_q=5.0, lam_r=1.0)                  # as specified in the manuscript
TUNED = dict(penalty_mode='prox', lam_q=0.01, lam_r=0.1)                    # chosen on validation split (seeds 1-3)
TUNED_NOREPLAY = dict(penalty_mode='prox', lam_q=0.1, lam_r=0.1)
jobs = []
for c in ['baseline', 'replay', 'qewc', 'replay_qewc', 'c_none', 'c_replay', 'c_ewc', 'c_replay_ewc', 'joint']:
    jobs.append(('main', 'spec_L1', c, SPEC, dict(layers=1)))
for c in ['qewc', 'c_ewc']: jobs.append(('main', 'tuned_L1', c, TUNED_NOREPLAY, dict(layers=1)))
for c in ['replay_qewc', 'c_replay_ewc']: jobs.append(('main', 'tuned_L1', c, TUNED, dict(layers=1)))
for c in ['baseline', 'replay', 'c_none', 'c_replay', 'joint']: jobs.append(('ctrl', 'base_L1', c, SPEC, dict(layers=1)))
for c in ['replay_qewc', 'c_replay_ewc']: jobs.append(('ctrl', 'tuned_L1', c, TUNED, dict(layers=1)))
for c in ['replay_qewc', 'c_replay_ewc']: jobs.append(('ctrl', 'spec_L1', c, SPEC, dict(layers=1)))
for c in ['baseline', 'replay', 'joint']: jobs.append(('main', 'base_L2', c, SPEC, dict(layers=2)))
jobs.append(('main', 'tuned_L2', 'replay_qewc', TUNED, dict(layers=2)))
done = set()
if os.path.exists(fn):
    for l in open(fn):
        r = json.loads(l); done.add((r['dataset'], r['config'], r['cond'], r['seed']))
out = open(fn, 'a'); cache = {}
for ds, cname, cond, over, extra in jobs:
    labs, f = DS[ds]
    if ds not in cache:
        d = np.load(f, allow_pickle=True); cache[ds] = (d['X'], np.array([labs.index(v) for v in d['y']]), d['g'])
    X, y, g = cache[ds]
    for s in range(1, 8):
        if (ds, cname, cond, s) in done: continue
        if time.time() - T0 > BUDGET: print('BUDGET STOP', flush=True); sys.exit(0)
        r = run(cond, X, y, g, TASKS, s, cfg_over=dict(over, **extra))
        r.update(dataset=ds, config=cname); out.write(json.dumps(r) + '\n'); out.flush()
print('ALL DONE', flush=True)
