import pandas as pd, numpy as np, json
from scipy import stats
r = pd.DataFrame([json.loads(l) for l in open('results_final.jsonl')])
pd.set_option('display.width', 220)
def ms(x): return f"{np.mean(x):.3f}±{np.std(x, ddof=1):.3f}"
rows = []
for (ds, cfg, cond), g in r.groupby(['dataset', 'config', 'cond']):
    rows.append(dict(dataset=ds, config=cfg, cond=cond, n=len(g), acc=ms(g.acc), bal=ms(g.bal_acc), f1=ms(g.f1_macro),
                     auc=ms(g.auc), bwt=ms(g.bwt) if g.bwt.notna().all() else '-', fgt=ms(g.forgetting) if g.forgetting.notna().all() else '-'))
T = pd.DataFrame(rows); print(T.to_string(index=False)); T.to_csv('table_all.csv', index=False)
def get(ds, cfg, cond, m): return r[(r.dataset == ds) & (r.config == cfg) & (r.cond == cond)].sort_values('seed')[m].values
print('\n-- paired tests (main, test split, 7 seeds), two-sided paired t / Wilcoxon')
pairs = [('spec_L1','baseline','spec_L1','replay'), ('spec_L1','replay','spec_L1','replay_qewc'), ('spec_L1','replay','tuned_L1','replay_qewc'),
         ('spec_L1','c_replay','spec_L1','c_replay_ewc'), ('spec_L1','c_replay','tuned_L1','c_replay_ewc'), ('spec_L1','replay','spec_L1','c_replay'),
         ('spec_L1','replay','spec_L1','joint'), ('spec_L1','c_replay','tuned_L1','replay_qewc')]
for (c1, a, c2, b) in pairs:
    for m in ['acc', 'bwt']:
        x, y = get('main', c1, a, m), get('main', c2, b, m)
        if np.isnan(x).any() or np.isnan(y).any(): continue
        d = y - x; t = stats.ttest_rel(y, x); w = stats.wilcoxon(y, x) if np.any(d != 0) else None
        print(f"{a}[{c1}] -> {b}[{c2}] {m}: mean diff {d.mean():+.3f} (95% CI {d.mean()-stats.t.ppf(.975,6)*d.std(ddof=1)/np.sqrt(7):+.3f},{d.mean()+stats.t.ppf(.975,6)*d.std(ddof=1)/np.sqrt(7):+.3f}) t-p={t.pvalue:.4f} wilcoxon-p={w.pvalue if w else float('nan'):.4f}")
print('\n-- per-class recall (main spec_L1, final stage, mean over seeds): Normal, Pneumonia, COVID, LungCancer')
for c in ['baseline','replay','replay_qewc','c_replay','joint']:
    g = r[(r.dataset=='main')&(r.config=='spec_L1')&(r.cond==c)]; print(c, np.mean(np.stack(g.recall_per_class),0).round(3))
print('\nz_std (feature scale) main spec: ', r[(r.dataset=='main')&(r.config=='spec_L1')].groupby('cond').z_std.mean().round(3).to_dict())
print('pca var', r.pca_var.mean().round(3), 'n_test main', r[r.dataset=='main'].n_test.unique(), 'ctrl', r[r.dataset=='ctrl'].n_test.unique())
