import numpy as np, json
from lqfl import *
DS = {'main': (['Normal','Pneumonia','COVID-19','Lung Cancer'],'feat_main.npz'), 'ctrl': (['Normal','Viral Pneumonia','COVID','Lung_Opacity'],'feat_ctrl.npz')}
T = [[0,1],[2],[3]]; out = open('results_mlp.jsonl','w')
for ds,(labs,f) in DS.items():
    d=np.load(f,allow_pickle=True); y=np.array([labs.index(v) for v in d['y']])
    for h in (3,16):
        for cond,cfg,over in [(f'mlp{h}_none','tuned',dict(penalty_mode='prox')),(f'mlp{h}_replay','tuned',dict(penalty_mode='prox')),(f'mlp{h}_joint','tuned',dict(penalty_mode='prox')),
                              (f'mlp{h}_replay_ewc','tuned',dict(penalty_mode='prox',lam_q=0.1,lam_r=0.1)),(f'mlp{h}_replay_ewc','spec',dict(penalty_mode='explicit',lam_q=5.0,lam_r=1.0))]:
            for s in range(1,8):
                r=run(cond,d['X'],y,d['g'],T,s,cfg_over=over); r.update(dataset=ds,config=cfg); r.pop('A',None); out.write(json.dumps(r)+'\n')
print('done')
