"""Exact batched 6-qubit statevector simulator (numpy) for the paper's circuit:
RY(x_i) embedding -> per-qubit RY(theta_i1), RZ(theta_i2) -> CNOT ring (0,1),(1,2),...,(4,5),(5,0) -> <Z_i>."""
import numpy as np
NQ = 6

def _apply_1q(psi, U, q):
    # psi: (B, 2,2,2,2,2,2); U: (2,2) or (B,2,2) acting on qubit q
    ax = q + 1
    psi = np.moveaxis(psi, ax, 1)                  # (B, 2, ...)
    sh = psi.shape
    psi = psi.reshape(sh[0], 2, -1)
    if U.ndim == 2:
        psi = np.einsum('ij,bjk->bik', U, psi)
    else:
        psi = np.einsum('bij,bjk->bik', U, psi)
    return np.moveaxis(psi.reshape(sh), 1, ax)

def _ry(a):
    a = np.asarray(a, float); c, s = np.cos(a / 2), np.sin(a / 2)
    U = np.zeros(a.shape + (2, 2), complex)
    U[..., 0, 0] = c; U[..., 0, 1] = -s; U[..., 1, 0] = s; U[..., 1, 1] = c
    return U

def _rz(a):
    a = np.asarray(a, float)
    U = np.zeros(a.shape + (2, 2), complex)
    U[..., 0, 0] = np.exp(-0.5j * a); U[..., 1, 1] = np.exp(0.5j * a)
    return U

def _cnot(psi, c, t):
    psi = psi.copy()
    idx1 = [slice(None)] * 7; idx1[c + 1] = 1          # control=1 subspace
    sub = psi[tuple(idx1)]                              # axes: batch + 5 qubit axes (control removed)
    t_ax = t + 1 - (1 if t > c else 0)
    psi[tuple(idx1)] = np.flip(sub, axis=t_ax)
    return psi

def circuit(X, theta, layers=1, final_ry=None):
    """X: (B,6) angles; theta: (layers,6,2) ; final_ry: optional (6,) measurement-basis rotation. Returns (B,6) <Z_i>."""
    B = X.shape[0]
    psi = np.zeros((B,) + (2,) * NQ, complex); psi[(slice(None),) + (0,) * NQ] = 1
    for q in range(NQ):
        psi = _apply_1q(psi, _ry(X[:, q]), q)
    per = (theta.ndim == 4)
    for l in range(layers):
        for q in range(NQ):
            a1 = theta[:, l, q, 0] if per else theta[l, q, 0]
            a2 = theta[:, l, q, 1] if per else theta[l, q, 1]
            psi = _apply_1q(psi, _ry(a1), q)
            psi = _apply_1q(psi, _rz(a2), q)
        for q in range(NQ):
            psi = _cnot(psi, q, (q + 1) % NQ)
    if final_ry is not None:
        for q in range(NQ):
            psi = _apply_1q(psi, _ry(final_ry[q]), q)
    p = (np.abs(psi) ** 2)
    out = np.empty((B, NQ))
    for q in range(NQ):
        ax = tuple(i + 1 for i in range(NQ) if i != q)
        m = p.sum(axis=ax)                              # (B,2)
        out[:, q] = m[:, 0] - m[:, 1]
    return out

def param_shift_grad(X, theta, dz_out, layers=1, final_ry=None):
    """Gradient of L w.r.t. theta using the parameter-shift rule. dz_out: (B,6)=dL/dz per sample (already /B).
    Returns grad with theta's shape."""
    idxs = list(np.ndindex(*theta.shape)); P = len(idxs); B = X.shape[0]
    th = np.repeat(theta[None], 2 * P, axis=0)                  # (2P, L,6,2)
    for k, idx in enumerate(idxs):
        th[2 * k][idx] += np.pi / 2; th[2 * k + 1][idx] -= np.pi / 2
    th = np.repeat(th, B, axis=0)                               # (2P*B, ...)
    Xr = np.tile(X, (2 * P, 1))
    z = circuit(Xr, th, layers, final_ry).reshape(2 * P, B, NQ)
    g = np.zeros_like(theta)
    for k, idx in enumerate(idxs):
        g[idx] = np.sum(dz_out * (z[2 * k] - z[2 * k + 1]) / 2.0)
    return g

if __name__ == '__main__':
    rng = np.random.default_rng(0)
    X = rng.uniform(0, np.pi, (5, 6)); th = rng.normal(0, 1, (1, 6, 2))
    z = circuit(X, th)
    # closed form check: product-state + CNOT permutation => z_i = prod of cos(x_j+theta_j1) over a subset
    c = np.cos(X + th[0, :, 0])
    print('z', z[0].round(4)); print('cos', c[0].round(4))
    # Is theta_{.,2} (RZ) inert for 1 layer?
    gz = param_shift_grad(X, th, np.ones((5, 6)) / 5)
    print('grad RY params', gz[0, :, 0].round(4)); print('grad RZ params', gz[0, :, 1].round(6))
    # which subset of cos does each z_i equal?
    import itertools
    for i in range(6):
        for r in range(1, 7):
            for S in itertools.combinations(range(6), r):
                if np.allclose(np.prod(c[:, S], axis=1), z[:, i], atol=1e-9):
                    print(f'z_{i} = prod cos over qubits {S}')
    th2 = rng.normal(0, 1, (2, 6, 2)); g2 = param_shift_grad(X, th2, np.ones((5, 6)) / 5, layers=2)
    print('2-layer: RZ grads (layer0):', g2[0, :, 1].round(4))
