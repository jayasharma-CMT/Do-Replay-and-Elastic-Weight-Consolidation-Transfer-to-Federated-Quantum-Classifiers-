import pandas as pd, numpy as np, json, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family': 'serif', 'font.size': 8, 'axes.linewidth': .6})
r = pd.DataFrame([json.loads(l) for l in open('results_final.jsonl')])
def vals(ds, cfg, cond, m='acc'): return r[(r.dataset == ds) & (r.config == cfg) & (r.cond == cond)].sort_values('seed')[m].values
# Fig 1: final accuracy per condition (main), spec vs stabilised Q-EWC
order = [('Baseline', 'spec_L1', 'baseline'), ('Replay', 'spec_L1', 'replay'), ('Q-EWC\n(as specified)', 'spec_L1', 'qewc'),
         ('Replay+Q-EWC\n(as specified)', 'spec_L1', 'replay_qewc'), ('Replay+Q-EWC\n(stabilised)', 'tuned_L1', 'replay_qewc'),
         ('Classical\nreplay', 'spec_L1', 'c_replay'), ('Classical\nreplay+EWC\n(as specified)', 'spec_L1', 'c_replay_ewc'),
         ('Classical\nreplay+EWC\n(stabilised)', 'tuned_L1', 'c_replay_ewc'), ('Joint\n(offline)', 'spec_L1', 'joint')]
fig, ax = plt.subplots(figsize=(7.0, 2.8)); 
for i, (lab, cfg, c) in enumerate(order):
    v = vals('main', cfg, c); ax.bar(i, v.mean(), color='#9bb7d4' if not c.startswith('c_') else '#d4b39b', edgecolor='k', lw=.5, yerr=v.std(ddof=1), capsize=2)
    ax.scatter(np.full(len(v), i) + np.random.default_rng(0).uniform(-.15, .15, len(v)), v, s=6, c='k', zorder=3)
ax.axhline(.25, ls=':', c='gray', lw=.7); ax.text(8.45, .26, 'chance', ha='right', fontsize=6, color='gray')
ax.set_xticks(range(len(order))); ax.set_xticklabels([o[0] for o in order], fontsize=5.8); ax.set_ylabel('Final accuracy (test, 7 seeds)'); ax.set_ylim(0, 1)
plt.tight_layout(); plt.savefig('fig1_final_accuracy.png', dpi=300); plt.savefig('fig1_final_accuracy.pdf'); plt.close()
# Fig 2: cumulative accuracy trajectory over the three stages
fig, ax = plt.subplots(figsize=(3.4, 2.6))
for lab, cfg, c, st in [('Baseline', 'spec_L1', 'baseline', '-o'), ('Replay', 'spec_L1', 'replay', '-s'), ('Replay+Q-EWC (stabilised)', 'tuned_L1', 'replay_qewc', '-^'),
                        ('Replay+Q-EWC (as specified)', 'spec_L1', 'replay_qewc', '--^'), ('Classical replay', 'spec_L1', 'c_replay', '-d')]:
    g = r[(r.dataset == 'main') & (r.config == cfg) & (r.cond == c)]
    cum = np.array([[A[str(t)]['acc'] for t in range(3)] for A in g.A]); ax.errorbar([1, 2, 3], cum.mean(0), cum.std(0, ddof=1), fmt=st, ms=3, lw=.8, capsize=1.5, label=lab)
ax.set_xticks([1, 2, 3]); ax.set_xticklabels(['Stage 1\n(N, P)', 'Stage 2\n(+COVID)', 'Stage 3\n(+Lung ca.)'], fontsize=6.5); ax.set_ylabel('Accuracy on all seen classes'); ax.set_ylim(0, 1); ax.legend(fontsize=5.5, loc='lower left')
plt.tight_layout(); plt.savefig('fig2_trajectory.png', dpi=300); plt.savefig('fig2_trajectory.pdf'); plt.close()
# Fig 3: validation lambda sweep for replay+Q-EWC (proximal)
s = pd.DataFrame([json.loads(l) for l in open('sweep_val.jsonl')]); s2 = pd.DataFrame([json.loads(l) for l in open('sweep2_val.jsonl')])
q = s[(s.cond == 'replay_qewc') & (s['mode'] == 'prox')].groupby(['lam_q', 'lam_r']).bal_acc.mean().unstack()
fig, ax = plt.subplots(figsize=(3.4, 2.4)); im = ax.imshow(q.values, cmap='viridis', vmin=.5, vmax=.8)
ax.set_xticks(range(len(q.columns))); ax.set_xticklabels(q.columns); ax.set_yticks(range(len(q.index))); ax.set_yticklabels(q.index)
for i in range(q.shape[0]):
    for j in range(q.shape[1]): ax.text(j, i, f'{q.values[i, j]:.2f}', ha='center', va='center', color='w', fontsize=7)
ax.set_xlabel(r'$\lambda_r$ (readout)'); ax.set_ylabel(r'$\lambda_q$ (circuit)'); plt.colorbar(im, label='Val. balanced acc.'); plt.tight_layout()
plt.savefig('fig3_lambda_sweep.png', dpi=300); plt.savefig('fig3_lambda_sweep.pdf'); plt.close()
# Fig 4: main vs all-X-ray control
fig, ax = plt.subplots(figsize=(3.4, 2.5)); conds = [('Baseline', 'base_L1', 'baseline'), ('Replay', 'base_L1', 'replay'), ('Replay+Q-EWC\n(stab.)', 'tuned_L1', 'replay_qewc'), ('Classical\nreplay', 'base_L1', 'c_replay'), ('Joint', 'base_L1', 'joint')]
w = .38
for k, (ds, col, lab) in enumerate([('main', '#9bb7d4', 'Main (X-ray + CT)'), ('ctrl', '#d4b39b', 'Control (X-ray only)')]):
    mm = [vals(ds, 'spec_L1' if ds == 'main' and c[1] == 'base_L1' else c[1], c[2]) for c in conds]
    ax.bar(np.arange(5) + (k - .5) * w, [m.mean() for m in mm], w, yerr=[m.std(ddof=1) for m in mm], color=col, edgecolor='k', lw=.5, capsize=1.5, label=lab)
ax.set_xticks(range(5)); ax.set_xticklabels([c[0] for c in conds], fontsize=5.5); ax.set_ylabel('Final accuracy'); ax.set_ylim(0, 1); ax.legend(fontsize=5.5); plt.tight_layout()
plt.savefig('fig4_control.png', dpi=300); plt.savefig('fig4_control.pdf'); plt.close(); print('figs ok')
