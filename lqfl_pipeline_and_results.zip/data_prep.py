"""Build manifests (path, label, patient/group id, source) and cache 134-d HOG+stats features.
Main experiment: Normal / Pneumonia (Kermany), COVID-19 frontal X-ray (ieee8023), Lung Cancer malignant CT (IQ-OTH/NCCD).
Control experiment: all-X-ray COVID-19 Radiography Database subset (Normal, Viral Pneumonia, Lung Opacity, COVID).
"""
import os, re, hashlib, glob, json, sys
import numpy as np, pandas as pd
from PIL import Image
from skimage.feature import hog
from scipy.stats import skew, kurtosis
import cv2

D = '/home/claude/data'

def md5(p):
    return hashlib.md5(open(p, 'rb').read()).hexdigest()

def phash(img64):
    g = cv2.resize(img64.astype(np.float32), (32, 32), interpolation=cv2.INTER_AREA)
    dct = cv2.dct(g)[:8, :8]
    med = np.median(dct[1:].ravel())
    return (dct > med).flatten()

def load_gray64(p):
    im = Image.open(p).convert('L').resize((64, 64), Image.LANCZOS)
    return np.asarray(im, dtype=np.float32) / 255.0

def feats(a):
    h = hog(a, orientations=8, pixels_per_cell=(16, 16), cells_per_block=(1, 1), feature_vector=True)
    f = a.ravel()
    st = [f.mean(), f.std(), skew(f), kurtosis(f), np.percentile(f, 5), np.percentile(f, 95)]
    return np.concatenate([h, st]).astype(np.float32)

def main_manifest():
    rows = []
    for p in glob.glob(f'{D}/kermany_normal/**/*.jpeg', recursive=True):
        m = re.search(r'NORMAL-(\d+)-\d+', os.path.basename(p))
        rows.append(dict(path=p, label='Normal', group='N' + (m.group(1) if m else os.path.basename(p)), source='Kermany'))
    for p in glob.glob(f'{D}/kermany_pneu/**/*.jpeg', recursive=True):
        m = re.search(r'(?:BACTERIA|VIRUS)-(\d+)-\d+', os.path.basename(p))
        rows.append(dict(path=p, label='Pneumonia', group='P' + (m.group(1) if m else os.path.basename(p)), source='Kermany'))
    md = pd.read_csv(f'{D}/covid_ieee/metadata.csv')
    md = md[md.finding.astype(str).str.contains('COVID-19') & (md.modality == 'X-ray') & md.view.isin(['PA', 'AP', 'AP Supine', 'AP Erect'])]
    have = {os.path.basename(p): p for p in glob.glob(f'{D}/covid_ieee/Covid-chestxray/*')}
    for _, r in md.iterrows():
        if r.filename in have:
            rows.append(dict(path=have[r.filename], label='COVID-19', group='C' + str(r.patientid), source='ieee8023'))
    # IQ-OTH/NCCD: malignant only; no patient id -> contiguous-block pseudo groups (heuristic, ~14 slices/case)
    for p in glob.glob(f'{D}/iqoth/**/Malignant cases/*.jpg', recursive=True):
        n = int(re.search(r'\((\d+)\)', p).group(1))
        rows.append(dict(path=p, label='Lung Cancer', group='L%d' % ((n - 1) // 14), source='IQ-OTH/NCCD'))
    return pd.DataFrame(rows)

def ctrl_manifest():
    rows = []
    spec = {'Normal': ('Normal', 'Normal'), 'Viral pneumonia': ('Viral Pneumonia', 'Viral Pneumonia'),
            'CoviD Opacity': ('Lung_Opacity', 'Lung_Opacity'), 'COVID': ('COVID', 'COVID')}
    for folder, (lab, mfile) in spec.items():
        meta = pd.read_excel(f'{D}/ctrl/meta/{mfile}.metadata.xlsx')
        meta['k'] = meta['FILE NAME'].astype(str).str.lower()
        url = dict(zip(meta.k, meta.URL))
        for p in glob.glob(f'{D}/ctrl/{folder}/*.png'):
            k = os.path.splitext(os.path.basename(p))[0].lower()
            rows.append(dict(path=p, label=lab, group='I' + k, source=url.get(k, 'unknown')))
    return pd.DataFrame(rows)

def process(df, name):
    n0 = len(df)
    df['md5'] = [md5(p) for p in df.path]
    df = df.drop_duplicates('md5').reset_index(drop=True)
    n1 = len(df)
    X, H = [], []
    for p in df.path:
        a = load_gray64(p)
        X.append(feats(a)); H.append(phash(a))
    X = np.stack(X); H = np.stack(H)
    # near-duplicate removal (pHash Hamming <= 2), keep first occurrence
    G = df.group.values
    keep = np.ones(len(df), bool)
    for i in range(len(df)):
        if not keep[i]: continue
        d = (H[i + 1:] != H[i]).sum(1)
        dup = np.where((d <= 2) & (G[i + 1:] != G[i]))[0] + i + 1   # near-duplicate in a DIFFERENT patient/group -> leakage risk
        keep[dup] = False
    log = dict(name=name, listed=n0, after_md5=n1, after_phash=int(keep.sum()))
    df = df[keep].reset_index(drop=True); X = X[keep]
    log['per_class'] = df.label.value_counts().to_dict()
    log['groups_per_class'] = df.groupby('label').group.nunique().to_dict()
    log['source_by_class'] = {k: v.value_counts().to_dict() for k, v in df.groupby('label').source}
    np.savez_compressed(f'/home/claude/lqfl/feat_{name}.npz', X=X, y=df.label.values, g=df.group.values, src=df.source.values)
    df.drop(columns=['md5']).to_csv(f'/home/claude/lqfl/manifest_{name}.csv', index=False)
    json.dump(log, open(f'/home/claude/lqfl/prep_{name}.json', 'w'), indent=1, default=str)
    print(json.dumps(log, indent=1, default=str))

if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'main'
    process(main_manifest() if which == 'main' else ctrl_manifest(), which)
