"""Federated continual learning with a hybrid quantum classifier (numpy statevector).
Conditions: baseline, replay, qewc, replay_qewc (quantum) and c_none, c_replay, c_ewc, c_replay_ewc (classical linear readout on PCA-6), joint (offline upper bound)."""
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import (precision_recall_fscore_support, roc_auc_score, cohen_kappa_score,
                             confusion_matrix, balanced_accuracy_score)
from qsim import circuit, param_shift_grad

CFG = dict(layers=1, clients=3, rounds=5, epochs=20, lr=0.5, ref_per_class=60, replay_per_class=60,
           lam_q=5.0, lam_r=1.0, ps_cap=15, floor=0.3, init_std=0.1, prep='global')

def softmax_masked(logits, seen):
    m = np.full(logits.shape, -1e9); m[:, seen] = logits[:, seen]
    m = m - m.max(1, keepdims=True); e = np.exp(m); return e / e.sum(1, keepdims=True)

class Model:
    def __init__(self, quantum, cfg, rng):
        self.q = quantum; self.cfg = cfg
        self.theta = rng.normal(0, cfg['init_std'], (cfg['layers'], 6, 2))
        self.W = rng.normal(0, cfg['init_std'], (6, 4)); self.b = np.zeros(4)
    def params(self): return dict(theta=self.theta.copy(), W=self.W.copy(), b=self.b.copy())
    def set(self, p): self.theta, self.W, self.b = p['theta'].copy(), p['W'].copy(), p['b'].copy()
    def feat(self, X, theta=None):
        return circuit(X, self.theta if theta is None else theta, self.cfg['layers']) if self.q else X
    def proba(self, X, seen): return softmax_masked(self.feat(X) @ self.W + self.b, seen)
    def grads(self, X, y, seen, rng):
        """Returns grads of mean CE loss over X; theta-grad via parameter-shift on <=ps_cap subsample."""
        z = self.feat(X); p = softmax_masked(z @ self.W + self.b, seen)
        d = p.copy(); d[np.arange(len(y)), y] -= 1; d /= len(y)
        gW = z.T @ d; gb = d.sum(0); gth = np.zeros_like(self.theta)
        if self.q:
            n = min(self.cfg['ps_cap'], len(y)); sub = rng.choice(len(y), n, replace=False)
            ps = self.proba(X[sub], seen); ds = ps.copy(); ds[np.arange(n), y[sub]] -= 1; ds /= n
            gth = param_shift_grad(X[sub], self.theta, ds @ self.W.T, self.cfg['layers'])
        return dict(theta=gth, W=gW, b=gb)

def fisher(model, Xr, yr, seen, rng, new_cols, cfg):
    g = model.grads(Xr, yr, seen, rng)
    F = {k: v ** 2 for k, v in g.items()}
    # theta grad is a subsample estimate: average several draws for stability
    if model.q:
        acc = np.zeros_like(F['theta'])
        for _ in range(5): acc += model.grads(Xr, yr, seen, rng)['theta'] ** 2
        F['theta'] = acc / 5
    for k in F:
        F[k] = F[k] / (F[k].mean() + 1e-12); F[k] = np.maximum(F[k], cfg['floor'])
    fisher.last = {k: (float(v.max()), float(np.percentile(v, 90))) for k, v in F.items()}
    return F

def make_prep(Xtr, ytr_task1_mask, cfg):
    fit = Xtr if cfg['prep'] == 'global' else Xtr[ytr_task1_mask]
    sc = StandardScaler().fit(fit); pca = PCA(6, random_state=0).fit(sc.transform(fit))
    P = pca.transform(sc.transform(fit)); lo, hi = P.min(0), P.max(0)
    def tf(X):
        Z = (pca.transform(sc.transform(X)) - lo) / (hi - lo + 1e-12)
        return np.clip(Z, 0, 1) * np.pi
    return tf, float(pca.explained_variance_ratio_.sum())

def grouped_split(y, g, rng, test_frac=0.25):
    te = np.zeros(len(y), bool)
    for c in np.unique(y):
        idx = np.where(y == c)[0]; groups = np.unique(g[idx]); rng.shuffle(groups)
        need = test_frac * len(idx); cnt = 0
        for gr in groups:
            if cnt >= need: break
            m = idx[g[idx] == gr]; te[m] = True; cnt += len(m)
    return ~te, te

def partition(n_by_class, ids_by_class, K, rng):
    """non-IID: 60% of each class to primary client (class % K), rest split evenly."""
    parts = [[] for _ in range(K)]
    for c, ids in ids_by_class.items():
        ids = rng.permutation(ids); n = len(ids); prim = c % K
        n_p = int(round(0.6 * n)); rest = ids[n_p:]; parts[prim] += list(ids[:n_p])
        others = [k for k in range(K) if k != prim]
        for j, chunk in enumerate(np.array_split(rest, len(others))): parts[others[j]] += list(chunk)
    return [np.array(p, int) for p in parts]

def local_train(model, X, y, seen, cfg, rng, ewc=None, new_cols=()):
    mode = cfg.get('penalty_mode', 'explicit')
    for _ in range(cfg['epochs']):
        g = model.grads(X, y, seen, rng)
        if ewc is not None and mode == 'explicit':
            F, ref = ewc
            mW = np.ones(4); mW[list(new_cols)] = 0                      # mask importance of new-class columns
            if model.q: g['theta'] = g['theta'] + cfg['lam_q'] * F['theta'] * (model.theta - ref['theta'])
            g['W'] = g['W'] + cfg['lam_r'] * F['W'] * mW[None, :] * (model.W - ref['W'])
            g['b'] = g['b'] + F['b'] * mW * (model.b - ref['b'])
        model.theta -= cfg['lr'] * g['theta']; model.W -= cfg['lr'] * g['W']; model.b -= cfg['lr'] * g['b']
        if ewc is not None and mode == 'prox':                            # implicit (proximal) step: unconditionally stable
            F, ref = ewc
            mW = np.ones(4); mW[list(new_cols)] = 0
            if model.q:
                a = cfg['lr'] * cfg['lam_q'] * F['theta']; model.theta = (model.theta + a * ref['theta']) / (1 + a)
            a = cfg['lr'] * cfg['lam_r'] * F['W'] * mW[None, :]; model.W = (model.W + a * ref['W']) / (1 + a)
            a = cfg['lr'] * F['b'] * mW; model.b = (model.b + a * ref['b']) / (1 + a)

def evaluate(model, X, y, seen, tasks, stage):
    p = model.proba(X[np.isin(y, seen)], seen); yy = y[np.isin(y, seen)]; pred = p.argmax(1)
    per = {}
    for j in range(stage + 1):
        m = np.isin(yy, tasks[j]); per[j] = float((pred[m] == yy[m]).mean()) if m.any() else np.nan
    return dict(acc=float((pred == yy).mean()), per_task=per)

def final_metrics(model, X, y, seen):
    p = model.proba(X, seen); pred = p.argmax(1)
    pr, rc, f1, _ = precision_recall_fscore_support(y, pred, labels=seen, average=None, zero_division=0)
    try: auc = roc_auc_score(y, p[:, seen], multi_class='ovr', average='macro', labels=seen)
    except Exception: auc = float('nan')
    return dict(acc=float((pred == y).mean()), bal_acc=float(balanced_accuracy_score(y, pred)),
                precision_macro=float(pr.mean()), recall_macro=float(rc.mean()), f1_macro=float(f1.mean()),
                auc=float(auc), kappa=float(cohen_kappa_score(y, pred)),
                recall_per_class=[float(v) for v in rc], f1_per_class=[float(v) for v in f1],
                confusion=confusion_matrix(y, pred, labels=seen).tolist())

def run(cond, Xraw, y, g, tasks, seed, cfg=None, cfg_over=None):
    cfg = dict(CFG, **(cfg_over or {})) if cfg is None else cfg
    rng = np.random.default_rng(seed)
    tr, te = grouped_split(y, g, np.random.default_rng(1000 + seed))     # split depends on seed only (shared across conditions)
    if cfg.get('use_val'):                                                 # tuning mode: never touch the test split
        idx_tr = np.where(tr)[0]; t2, v2 = grouped_split(y[idx_tr], g[idx_tr], np.random.default_rng(2000 + seed), 0.2)
        tr = np.zeros(len(y), bool); tr[idx_tr[t2]] = True; te = np.zeros(len(y), bool); te[idx_tr[v2]] = True
    task1 = np.isin(y[tr], tasks[0])
    tf, var = make_prep(Xraw[tr], task1, cfg)
    Xtr, ytr, Xte, yte = tf(Xraw[tr]), y[tr], tf(Xraw[te]), y[te]
    quantum = not cond.startswith('c_')
    use_replay = 'replay' in cond; use_ewc = 'ewc' in cond or cond.endswith('qewc')
    model = Model(quantum, cfg, np.random.default_rng(seed))              # same init across conditions with same quantum flag
    K = cfg['clients']; buffer = {}; ewc = None; A = {}; seen = []
    stages = [list(range(len(tasks)))] if cond == 'joint' else None
    sched = [sum(tasks, [])] if cond == 'joint' else tasks
    rounds = cfg['rounds'] * (len(tasks) if cond == 'joint' else 1)
    for t, newc in enumerate(sched):
        seen = sorted(set(seen) | set(newc)); old = [c for c in seen if c not in newc]
        ids = {c: np.where(ytr == c)[0] for c in newc}
        parts = partition(None, ids, K, rng)
        for r in range(rounds):
            plist, ns = [], []
            base = model.params()
            for k in range(K):
                model.set(base); idk = parts[k]
                if len(idk) == 0: continue
                Xk, yk = Xtr[idk], ytr[idk]
                if use_replay and old and buffer:
                    n_new_c = max(1, len(idk) // len(newc))
                    rx = [np.resize(buffer[c][0], (n_new_c, 6)) for c in old if c in buffer]    # tile each old class to ~ new-class count (Eq. 11)
                    ry = [np.full(n_new_c, c) for c in old if c in buffer]
                    Xk = np.vstack([Xk] + rx); yk = np.concatenate([yk] + ry)
                local_train(model, Xk, yk, seen, cfg, rng, ewc if (use_ewc and ewc is not None) else None, new_cols=newc)
                plist.append(model.params()); ns.append(len(yk))
            w = np.array(ns) / sum(ns)
            model.set({k: sum(wi * p[k] for wi, p in zip(w, plist)) for k in plist[0]})
        if cond != 'joint':
            for c in newc:                                                     # replay buffer: <=60/class of newly learned classes
                idc = np.where(ytr == c)[0]; sel = rng.choice(idc, min(cfg['replay_per_class'], len(idc)), replace=False)
                buffer[c] = (Xtr[sel], ytr[sel])
            if use_ewc:                                                        # reference buffer from all classes seen so far
                rx = np.vstack([Xtr[rng.choice(np.where(ytr == c)[0], min(cfg['ref_per_class'], (ytr == c).sum()), replace=False)] for c in seen])
                ry = np.concatenate([np.full(min(cfg['ref_per_class'], (ytr == c).sum()), c) for c in seen])
                ewc = (fisher(model, rx, ry, seen, rng, newc, cfg), model.params())
            A[t] = evaluate(model, Xte, yte, seen, tasks, t)
    if cond == 'joint':
        A[len(tasks) - 1] = evaluate(model, Xte, yte, seen, tasks, len(tasks) - 1)
    T = len(tasks); last = A[T - 1]['per_task']
    bwt = float(np.mean([last[i] - A[i]['per_task'][i] for i in range(T - 1)])) if cond != 'joint' else float('nan')
    fgt = float(np.mean([max(A[l]['per_task'][i] for l in range(i, T - 1)) - last[i] for i in range(T - 1)])) if cond != 'joint' else float('nan')
    out = final_metrics(model, Xte, yte, seen)
    out.update(cond=cond, seed=seed, bwt=bwt, forgetting=fgt, pca_var=var, n_train=int(tr.sum()), n_test=int(te.sum()),
               A={str(t): A[t] for t in A}, z_std=float(model.feat(Xte).std(0).mean()))
    return out
