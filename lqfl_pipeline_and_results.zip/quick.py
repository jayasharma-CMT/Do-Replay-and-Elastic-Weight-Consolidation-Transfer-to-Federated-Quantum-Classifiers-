import numpy as np, time, json
from lqfl import *
d = np.load('feat_main.npz', allow_pickle=True)
lab = ['Normal', 'Pneumonia', 'COVID-19', 'Lung Cancer']; y = np.array([lab.index(v) for v in d['y']])
tasks = [[0, 1], [2], [3]]
for cond in ['baseline', 'replay', 'qewc', 'replay_qewc', 'c_none', 'c_replay', 'joint']:
    t = time.time(); r = run(cond, d['X'], y, d['g'], tasks, 1)
    print(f"{cond:12s} acc={r['acc']:.3f} bal={r['bal_acc']:.3f} f1={r['f1_macro']:.3f} bwt={r['bwt']:.3f} fgt={r['forgetting']:.3f} zstd={r['z_std']:.3f} ntest={r['n_test']} pcavar={r['pca_var']:.3f} {time.time()-t:.0f}s")
