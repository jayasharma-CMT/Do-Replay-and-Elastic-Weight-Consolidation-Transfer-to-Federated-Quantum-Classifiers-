import numpy as np, json, sys, itertools, time
from lqfl import *
d = np.load('feat_main.npz', allow_pickle=True)
lab = ['Normal','Pneumonia','COVID-19','Lung Cancer']; y = np.array([lab.index(v) for v in d['y']]); tasks=[[0,1],[2],[3]]
import os
BUDGET = float(sys.argv[1]) if len(sys.argv) > 1 else 150; T0 = time.time()
done = set()
if os.path.exists('sweep_val.jsonl'):
    for l in open('sweep_val.jsonl'):
        r = json.loads(l); done.add((r['cond'], r['mode'], r['lam_q'], r['lam_r'], r['seed']))
out = open('sweep_val.jsonl', 'a'); seeds = [1, 2, 3]
jobs = []
for cond in ['replay_qewc', 'qewc']:
    for lq, lr_ in itertools.product([0.1, 1.0, 5.0], [0.1, 1.0, 5.0]): jobs.append((cond, 'prox', lq, lr_))
    for lq, lr_ in [(5.0, 1.0), (0.5, 0.1), (0.1, 0.1)]: jobs.append((cond, 'explicit', lq, lr_))
for cond in ['c_replay_ewc', 'c_ewc']:
    for lr_ in [0.1, 0.5, 1.0, 5.0]:
        for mode in ['prox', 'explicit']: jobs.append((cond, mode, 0.0, lr_))
for cond, mode, lq, lr_ in jobs:
    for s in seeds:
        if (cond, mode, lq, lr_, s) in done: continue
        if time.time() - T0 > BUDGET: print('BUDGET STOP', flush=True); sys.exit(0)
        r = run(cond, d['X'], y, d['g'], tasks, s, cfg_over=dict(use_val=True, penalty_mode=mode, lam_q=lq, lam_r=lr_))
        r.update(mode=mode, lam_q=lq, lam_r=lr_); r.pop('A', None)
        out.write(json.dumps(r) + '\n'); out.flush()
    print(cond, mode, lq, lr_, 'done', flush=True)
print('ALL DONE', flush=True)
