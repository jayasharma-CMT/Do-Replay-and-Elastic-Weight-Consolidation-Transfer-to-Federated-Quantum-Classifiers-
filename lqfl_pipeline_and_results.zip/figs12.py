import pandas as pd, numpy as np, json, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family': 'serif', 'font.size': 7.5, 'axes.linewidth': .6})
r = pd.DataFrame([json.loads(l) for l in open('results_final.jsonl')])
def vals(cfg, cond): return r[(r.dataset == 'main') & (r.config == cfg) & (r.cond == cond)].sort_values('seed')['acc'].values
order = [('Baseline (no mitigation)', 'spec_L1', 'baseline', 'q'), ('Replay', 'spec_L1', 'replay', 'q'), ('Q-EWC, as specified', 'spec_L1', 'qewc', 'q'),
         ('Replay + Q-EWC, as specified', 'spec_L1', 'replay_qewc', 'q'), ('Replay + Q-EWC, stabilized', 'tuned_L1', 'replay_qewc', 'q'),
         ('Classical replay', 'spec_L1', 'c_replay', 'c'), ('Classical replay + EWC, as specified', 'spec_L1', 'c_replay_ewc', 'c'),
         ('Classical replay + EWC, stabilized', 'tuned_L1', 'c_replay_ewc', 'c'), ('Joint training (offline)', 'spec_L1', 'joint', 'j')]
col = {'q': '#9bb7d4', 'c': '#d4b39b', 'j': '#bdbdbd'}
fig, ax = plt.subplots(figsize=(3.45, 3.1)); n = len(order)
for i, (lab, cfg, c, k) in enumerate(order):
    v = vals(cfg, c); y = n - 1 - i
    ax.barh(y, v.mean(), color=col[k], edgecolor='k', lw=.5, xerr=v.std(ddof=1), capsize=2, error_kw=dict(lw=.7))
    ax.scatter(v, np.full(len(v), y) + np.random.default_rng(i).uniform(-.18, .18, len(v)), s=5, c='k', zorder=3)
ax.axvline(.25, ls=':', c='gray', lw=.7); ax.text(.255, -0.9, 'chance', fontsize=6, color='gray')
ax.set_yticks(range(n)); ax.set_yticklabels([o[0] for o in order][::-1], fontsize=6.5); ax.set_xlim(0, 1); ax.set_ylim(-1.1, n - .4); ax.set_xlabel('Final test accuracy (7 seeds)')
plt.tight_layout(); plt.savefig('fig1_final_accuracy.png', dpi=300); plt.savefig('fig1_final_accuracy.pdf'); plt.close()
fig, ax = plt.subplots(figsize=(3.4, 3.0))
for lab, cfg, c, st in [('Baseline', 'spec_L1', 'baseline', '-o'), ('Replay', 'spec_L1', 'replay', '-s'), ('Replay + Q-EWC (stabilized)', 'tuned_L1', 'replay_qewc', '-^'),
                        ('Replay + Q-EWC (as specified)', 'spec_L1', 'replay_qewc', '--^'), ('Classical replay', 'spec_L1', 'c_replay', '-d')]:
    g = r[(r.dataset == 'main') & (r.config == cfg) & (r.cond == c)]
    cum = np.array([[A[str(t)]['acc'] for t in range(3)] for A in g.A]); ax.errorbar([1, 2, 3], cum.mean(0), cum.std(0, ddof=1), fmt=st, ms=3, lw=.8, capsize=1.5, label=lab)
ax.set_xticks([1, 2, 3]); ax.set_xticklabels(['Stage 1\n(normal, pneumonia)', 'Stage 2\n(+COVID-19)', 'Stage 3\n(+lung cancer)'], fontsize=6.5)
ax.set_ylabel('Accuracy on all seen classes'); ax.set_ylim(0, 1)
ax.legend(fontsize=5.8, loc='upper center', bbox_to_anchor=(.5, -.2), ncol=2, frameon=False)
plt.tight_layout(); plt.savefig('fig2_trajectory.png', dpi=300); plt.savefig('fig2_trajectory.pdf'); plt.close(); print('ok')
