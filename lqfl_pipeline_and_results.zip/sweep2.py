import numpy as np, json, sys, time, os
from lqfl import *
d = np.load('feat_main.npz', allow_pickle=True)
lab = ['Normal','Pneumonia','COVID-19','Lung Cancer']; y = np.array([lab.index(v) for v in d['y']]); tasks=[[0,1],[2],[3]]
BUDGET = float(sys.argv[1]); T0 = time.time(); fn = 'sweep2_val.jsonl'
done = set()
if os.path.exists(fn):
    for l in open(fn):
        r = json.loads(l); done.add((r['cond'], r['mode'], r['lam_q'], r['lam_r'], r['seed']))
out = open(fn, 'a')
jobs = [(c, 'prox', 0.0, 0.0) for c in ['c_none', 'c_replay', 'replay', 'baseline', 'joint']]
jobs += [('replay_qewc', 'prox', lq, 0.1) for lq in [0.0, 0.01, 0.03]]
for cond, mode, lq, lr_ in jobs:
    for s in [1, 2, 3]:
        if (cond, mode, lq, lr_, s) in done: continue
        if time.time() - T0 > BUDGET: print('BUDGET STOP'); sys.exit(0)
        r = run(cond, d['X'], y, d['g'], tasks, s, cfg_over=dict(use_val=True, penalty_mode=mode, lam_q=lq, lam_r=lr_))
        r.update(mode=mode, lam_q=lq, lam_r=lr_); r.pop('A', None); out.write(json.dumps(r) + '\n'); out.flush()
print('ALL DONE')
